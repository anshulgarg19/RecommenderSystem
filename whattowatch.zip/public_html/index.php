<!DOCTYPE html>
<html lang = "en">
<head>
	<meta charset = "UTF-8">
	<link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="css/style-original.css" rel="stylesheet" media="screen">
	<title>Recommender System</title>
</head>

<body class = 'thebackground'>
<div>
<H1 style = "text-align : center">Movie Recommender System </H1>
<br><br><br><br><br><br><br>
<center>
	<div style = "width : 320px; padding : 10px; border : 0px solid gray;margin : 0;text-align : center">
	<H2><a href = "movielist.php">Movie List</a><H2>
	<H2><a href = "login.php">Login</a></H2>
	<H2><a href = "register.php">Register</a><H2>
	</div>
</center>

<div>    
	<div style=" position : fixed;text-align : center;bottom: 5px; width :100%;font-size : 20px">
	Developed by 
		<b><a href = "https://www.facebook.com/anshul.garg.52643?fref=ts">Anshul Garg</a> & 
		<a href="https://www.facebook.com/pulkit.aggarwal.9?fref=ts">Pulkit Aggarwal</a></b>
	</div>
</div>
</body>
</html>
