<?php
session_start();
include_once 'dbconnect.php';
$userid = $_SESSION['user'];
$query = array();
$totalMovies = 1000;
$query = mysql_query("SELECT movieId,rating from ratingDetails where userId = '$userid' and movieId <= '$totalMovies'");

 $i = 0;
 $res = array();
        while($row = mysql_fetch_assoc($query) )
        {
                $res[$i]['movieId'] = $row['movieId'];
                $res[$i]['rating'] = $row['rating'];
                $i++;
        }

$result = array();

if( $i == 0 )	//for a new registered user
{
	$q = mysql_query("SELECT movieTitle from movieProfile order by year DESC LIMIT 10");
	$i;
	while( $line = mysql_fetch_assoc( $q ))
	{
		$result[$i] = $line['movieTitle'];
		$i++;
	}
}
else	// for existing user
{	

	//optimized query
//	$q = mysql_query("select m.movieId,m.movieTitle from ratingDetails as r right outer join movieProfile as m on r.movieId = m.movieId where r.movieId = NULL and r.userId = \'$userid\' and m.movieId <= \'$totalMovies\';");
	$q = mysql_query("SELECT movieId,movieTitle from movieProfile where  movieId <= '$totalMovies' and movieId not in('SELECT movieId from ratingDetails where userId = \'$userid\' and movieId <= \'$totalMovies\'')");//list of movies not watched by that user
	
//	echo count($q);
	$i = 0;
	$col = array();	//stores movies not seen
	
	while($row = mysql_fetch_assoc($q))
	{
		$col[$i]['movieId'] = $row['movieId'];
		$col[$i]['movieTitle'] = $row['movieTitle'];
		$i++;
	}

//	echo count($col);	
	$weighted_average_array = array();
	
	for($i=0;$i < sizeof($col);$i++)
	{
		$final_score = 0;
		$total_similiarity = 0;
	
		
		for($j=0;$j < sizeof($res);$j++)
		{
			$mId1 = $col[$i]['movieId'];
			$mId2 = $res[$j]['movieId'];
			$score_query = mysql_query("SELECT score from similarityDetails where (mId1 = '$mId1' and mId2 = '$mId2') or (mId1 = '$mId2' and mId2 = '$mId1')");
		//	$score = mysql_query("SELECT score from similarityDetails where (mId1 = '$col[$i][\'movieId\']' and mId2 = '$res[$j]['movieId']\') or (mId1 = \'$res[$j]['movieId']\' and mId2 = \'$col[$i]['movieId']\')");

			$sq = mysql_fetch_array($score_query, MYSQL_NUM );
			$score = $sq[0];
			$final_score += $score*$res[$j]['rating'];
			$total_similarity += $score;
		}
	
		$final_score /= $total_similarity;
	
		$weighted_average_array[$col[$i]['movieTitle']] = $final_score;
	}
	
	array_multisort($weighted_average_array,SORT_DESC);
	
	$result = array_keys($weighted_average_array);
	$result = array_slice($result,0,20);
//	echo sizeof($result);
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>cleartuts - Login & Registration System</title>
<link rel="stylesheet" href="style.css" type="text/css" />
</head>
<body>
Your Recommendations:
<table>
	<?php	
	foreach($result as $movie)
	{
		?>
		<tr>
		<td><?php echo $movie; ?></td>
		</tr>
		<?php } ?>
</table>
<a href="logout.php">Logout</a>
</body>
</html>
